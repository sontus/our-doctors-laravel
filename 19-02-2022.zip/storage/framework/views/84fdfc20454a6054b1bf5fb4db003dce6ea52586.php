<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <meta charset="utf-8">
    <meta name="keywords" content="" />
	<meta name="author" content="" />
	<meta name="robots" content="" />
    <meta name="viewport" content="width=device-width,initial-scale=1">
	<meta name="description" content="Laravel Project Starter" />
	<meta property="og:title" content="Laravel Project Starter" />
	<meta property="og:description" content="Laravel Project Starter" />
	<meta property="og:image" content="" />
	<meta name="format-detection" content="telephone=no">
    <title>Laravel Project Starter | <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/backend/images/favicon.png')); ?>">
	<link href="<?php echo e(asset('assets/backend/vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('assets/backend/css/style.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldPushContent('vendor-css'); ?>
    <?php echo $__env->yieldPushContent('onpage-css'); ?>
</head>

<body class="vh-100">

    <?php echo $__env->yieldContent('content'); ?>

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="<?php echo e(asset('assets/backend/vendor/global/global.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/backend/vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
    
    <?php echo $__env->yieldPushContent('vendor-js'); ?>
    <?php echo $__env->yieldPushContent('onpage-js'); ?>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/our-doctors-laravel/resources/views/layouts/auth.blade.php ENDPATH**/ ?>