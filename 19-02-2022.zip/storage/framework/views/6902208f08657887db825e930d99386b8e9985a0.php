<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="keywords" content="" />
	<meta name="author" content="" />
	<meta name="robots" content="" />
    <meta name="viewport" content="width=device-width,initial-scale=1">
	<meta name="description" content="Our-Doctors - Web" />
	<meta property="og:title" content="Our-Doctors - Web" />
	<meta property="og:description" content="Our-Doctors - Web" />
	<meta property="og:image" content="" />
	<meta name="format-detection" content="telephone=no">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Our-Doctors')); ?> | <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <!-- laravel-toastr css -->
    <link href="<?php echo e(asset('assets/backend/css/toastr.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- sweetalert2 css -->
    <link href="<?php echo e(asset('assets/backend/css/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/backend/vendor/chartist/css/chartist.min.css')); ?>">
    <link href="<?php echo e(asset('assets/backend/vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('assets/backend/vendor/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/backend/css/style.css')); ?>" rel="stylesheet">
    <style>
        .req{
            color:red;
            font-weight: 700;
        }
    </style>
    <?php echo $__env->yieldPushContent('vendor-css'); ?>
    <?php echo $__env->yieldPushContent('onpage-css'); ?>
</head>
<body>
    <!--*******************
        Preloader start
    ********************-->
    <?php echo $__env->make('layouts.partials.backend.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--*******************
        Preloader end
    ********************-->
    <div id="main-wrapper">
        <!--**********************************
            Nav header start
        ***********************************-->
       <?php echo $__env->make('layouts.partials.backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Nav header end
        ***********************************-->

		<!--**********************************
            Header start
        ***********************************-->
        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php echo $__env->make('layouts.partials.backend.left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <?php echo $__env->yieldContent('content'); ?>
        <!--**********************************
            Content body end
        ***********************************-->
        <!--**********************************
            Footer start
        ***********************************-->
       <?php echo $__env->make('layouts.partials.backend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Footer end
        ***********************************-->
    </div>

    <!-- Required vendors -->
    <script src="<?php echo e(asset('assets/backend/vendor/global/global.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
    

    <!-- Dashboard 1 -->
    

    
    <script src="<?php echo e(asset('assets/backend/js/custom.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/js/deznav-init.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/js/demo.js')); ?>"></script>
     <!-- laravel-toastr css -->
    
    <script src="<?php echo e(asset('assets/backend/js/toastr.min.js')); ?>"></script>
    <!-- sweetalert2 css -->
    <script src="<?php echo e(asset('assets/backend/js/sweetalert2.min.js')); ?>"></script>
    <?php echo Toastr::message(); ?>

        <script>
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    toastr.error('<?php echo e($error); ?>','Error',{
                    closeButton:true,
                    progressBar: true,
                });
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            //
        // Delete Item
        function deleteItem(id) {
            swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                confirmButtonClass: 'btn btn-danger',
                cancelButtonClass: 'btn btn-success mr-3',
                buttonsStyling: false,
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    event.preventDefault();
                    document.getElementById('delete-form-'+id).submit();
                } else if (
                    // Read more about handling dismissals
                    result.dismiss === swal.DismissReason.cancel
                ) {
                    swal(
                        'Cancelled',
                        'Your data is safe :)',
                        'error'
                    )
                }
            })
        }
        </script>
    <?php echo $__env->yieldPushContent('vendor-js'); ?>
    <?php echo $__env->yieldPushContent('onpage-js'); ?>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/our-doctors-laravel/resources/views/layouts/backend.blade.php ENDPATH**/ ?>