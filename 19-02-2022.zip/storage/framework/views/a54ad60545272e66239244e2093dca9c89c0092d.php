       <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="deznav">
            <div class="deznav-scroll">
				
				<ul class="metismenu" id="menu">
					<li class="nav-label first">Main Menu</li>
					<li>
						<a href="<?php echo e(route('dashboard')); ?>" class="ai-icon" aria-expanded="false">
							<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>
					<li>
						<a href="<?php echo e(route('category.index')); ?>" class="ai-icon" aria-expanded="false">
							<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Category</span>
						</a>
					</li>
					<li>
						<a href="<?php echo e(route('hospital.index')); ?>" class="ai-icon" aria-expanded="false">
							<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Hospitals</span>
						</a>
					</li>
					<li>
						<a href="<?php echo e(route('doctor.index')); ?>" class="ai-icon" aria-expanded="false">
						<i class="flaticon-381-settings-2"></i>
						<span class="nav-text">Doctors</span>
						</a>
					</li>
					<li>
						<a href="<?php echo e(route('chamber.index')); ?>" class="ai-icon" aria-expanded="false">
							<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Chambers</span>
						</a>
					</li>
					
					<li>
						<a href="<?php echo e(route('review.index')); ?>" class="ai-icon" aria-expanded="false">
						<i class="flaticon-381-settings-2"></i>
						<span class="nav-text">Reviews</span>
						</a>
					</li>
					
					
				

                </ul>
				
			</div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************--><?php /**PATH /opt/lampp/htdocs/our-doctors-laravel/resources/views/layouts/partials/backend/left-sidebar.blade.php ENDPATH**/ ?>