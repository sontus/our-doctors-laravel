  <!--**********************************
            Footer start
        ***********************************-->
    <div class="footer">
        <div class="copyright">
            <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank">OurDoctors</a> <?php echo e(date('Y')); ?></p>
        </div>
    </div>
    <!--**********************************
        Footer end
    ***********************************--><?php /**PATH /opt/lampp/htdocs/our-doctors-laravel/resources/views/layouts/partials/backend/footer.blade.php ENDPATH**/ ?>