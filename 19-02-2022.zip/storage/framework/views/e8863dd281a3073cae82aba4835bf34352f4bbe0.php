<?php $__env->startSection('title','Doctor List'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

        <!-- search start -->
    <div class="search">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">
                    <h1>Search for <?php echo e($search_text); ?></h1>
                </div>
            </div>

            <div class="row mt-5 search-box">
                <div class="col-sm-12 col-md-12 col-lg-12">
                    <form class="d-flex" action="<?php echo e(route('doctor-search')); ?>" method="GET">
                        <?php echo csrf_field(); ?>
                        <input class="form-control me-2" type="text" placeholder="Search for doctor name or specialist name" aria-label="Search" name="doctor_name">

                        <button class="btn btn-success search-button" type="submit">SEARCH</button>
                    </form>
                </div>
            </div>
            <div class="row search-result mt-3">
                <p><?php echo e($doctors->count()); ?> Search Results Found</p>
            </div>
        </div>
    </div>
        <!-- search end -->

    <!-- header end -->
    <!-- doctors start -->
    <div class="container m-5">
        <div class="row doctor-list">

            <div class="col-sm-12 col-md-9 col-lg-9 offset-1">

                <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="col-sm-2 col-md-2 col-lg-2 offset-1">
                            <img src="<?php echo e(asset('storage/doctors/'.$doctor->image )); ?>" alt="doctors" >
                        </div>
                        <div class="col-sm-5 col-md-5 col-lg-5">
                            <h4> <a href="<?php echo e(route('doctor-detail',$doctor->id)); ?>"> <?php echo e($doctor->doctor_name); ?></a> </h4>
                            <p><?php echo e($doctor->category->name); ?>  |  Experience <?php echo e($doctor->age); ?>+ years</p>
                            <p><?php echo e($doctor->degree); ?></p>
                            <div class="review-star-box">
                                <div class="star">
                                    <ul>
                                        <li> <i class="fas fa-star"></i></li>
                                        <li> <i class="fas fa-star"></i></li>
                                        <li> <i class="fas fa-star"></i></li>
                                        <li> <i class="fas fa-star"></i></li>
                                        <li> <i class="fas fa-star"></i></li>
                                    </ul>
                                </div>

                            </div>
                        </div>
                        <div class="col-sm-12 col-md-4 col-lg-4">
                            <h5><?php echo e($doctor->hospital->name); ?></h5>
                            <p class="mt-2"><span class="fas fa-map-marker-alt"></span> <?php echo e($doctor->hospital->address); ?></p>
                            <p> <span class="fas fa-phone-alt"></span> <?php echo e($doctor->hospital->phone); ?></p>
                        </div>
                    </div>
                    <hr/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>

        </div>
    </div>
    <!-- doctors end-->






<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/our-doctors-laravel/resources/views/doctor-result.blade.php ENDPATH**/ ?>