
    <!-- header start -->
    <header>
        <div class="container">
            <div class="row">
                <nav class="navbar navbar-expand-lg navbar-light ">
                    <div class="container-fluid">
                      <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                          <img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="logo" />
                      </a>
                      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                      </button>
                      <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
                        <ul class="navbar-nav me-auto mt-2 mb-2 mb-lg-0">
                          <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="<?php echo e(route('doctor')); ?>">Find Doctors</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('hospital')); ?>">Find Hospitals</a>
                          </li>

                        </ul>
                        <div class="d-flex">
                            <?php if(auth()->guard()->guest()): ?>
                                <button class="btn btn-outline" data-bs-toggle="modal" data-bs-target="#login">Login</button>
                                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#signup" >Signup</button>
                            <?php else: ?>

                                    <a class="btn" href="#" style="margin-right: 5px;"><?php echo e(Auth::user()->name); ?></a>
                                    <a class="btn btn-success" href="<?php echo e(route('logout')); ?>">Logout</a>

                            <?php endif; ?>

                        </div>
                      </div>
                    </div>
                  </nav>
            </div>
        </div>

        <!-- Modal -->
      <div class="modal fade " id="login" tabindex="-1" aria-labelledby="loginLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title text-center" id="loginLabel"></h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div class="row">
                  <div class="col-md-10 offset-md-1 ">
                      <div class="logo  d-flex justify-content-center">
                        <img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="logo" />
                      </div>
                      <div class="d-flex justify-content-center m-2">
                        <h5 class="mt-5">Login to your account</h5>
                      </div>
                      <div  class="d-flex justify-content-center m-2">
                        <form method="POST" action="<?php echo e(route('member-login')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                              

                              <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" placeholder="hello@example.com" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 mt-3">
                              
                              <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" name="password" required autocomplete="current-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-success mb-3">Login</button>
                                
                            </div>
                        </form>
                      </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      
      <div class="modal fade " id="signup" tabindex="-1" aria-labelledby="signupLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title text-center" id="signupLabel"></h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div class="row">
                  <div class="col-md-10 offset-md-1 ">
                      <div class="logo  d-flex justify-content-center">
                        <img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="logo" />
                      </div>
                      <div class="d-flex justify-content-center m-2">
                        <h5 class="mt-5">Signup to OurDoctors</h5>
                      </div>
                      <div  class="d-flex justify-content-center m-2">
                        <form method="POST" action="<?php echo e(route('member-register')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <input id="text" type="full_name" class="form-control <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('full_name')); ?>" required autocomplete="full_name" placeholder="Full Name" autofocus required>

                                  <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <span class="invalid-feedback" role="alert">
                                          <strong><?php echo e($message); ?></strong>
                                      </span>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                            <div class="mb-3">
                              

                              <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" placeholder="Enter Your Email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus required>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 mt-3">
                              <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" name="password" required autocomplete="current-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 mt-3">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="Confirm Password" required autocomplete="new-password">

                                  <?php $__errorArgs = ['password-confirm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <span class="invalid-feedback" role="alert">
                                          <strong><?php echo e($message); ?></strong>
                                      </span>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-success mb-3">Create an account </button>
                                <p>
                                    Already a member?
                                </p>
                                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#login">Login</button>

                            </div>
                        </form>
                      </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="modal fade " id="doctorsignup" tabindex="-1" aria-labelledby="doctorsignupLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title text-center" id="doctorsignupLabel"></h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div class="row">
                  <div class="col-md-10 offset-md-1 ">
                      <div class="logo  d-flex justify-content-center">
                        <img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="logo" />
                      </div>
                      <div class="d-flex justify-content-center m-2">
                        <h5 class="mt-5">Claim Doctor Profile</h5>
                      </div>
                      <div  class="">
                        <form action="<?php echo e(route('doctor-register')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="doctor_name">Your Legal Name <span class="req">*</span> </label>
                                        <input type="text" class="form-control" id="doctor_name" name="doctor_name" value="<?php echo e(old('doctor_name', empty($errors->doctor_name) ? '' : $errors->doctor_name)); ?>" placeholder="Your Legal Name">
                                        <?php if($errors->has('doctor_name')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('doctor_name')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="doctor_degree">Degree <span class="req">*</span> </label>
                                        <input type="text" class="form-control" id="doctor_degree" name="doctor_degree" value="<?php echo e(old('doctor_degree', empty($errors->doctor_degree) ? '' : $errors->doctor_degree)); ?>" placeholder="Example: MBBS">
                                        <?php if($errors->has('doctor_degree')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('doctor_degree')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-md-6">
                                        <label for="doctor_category">Practicing Department <span class="req">*</span> </label>
                                        <select name="doctor_category" id="doctor_category" class="form-control">
                                            <?php
                                                $categories = \DB::table('categories')->where('row_status',true)->latest()->get();
                                                $hospitals  = \DB::table('hospitals')->where('row_status',true)->latest()->get();
                                            ?>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                        <?php if($errors->has('doctor_category')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('doctor_category')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="doctor_hospital">Hospitals <span class="req">*</span> </label>
                                        <select name="doctor_hospital" id="doctor_hospital" class="form-control">
                                            <?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($hospital->id); ?>"><?php echo e($hospital->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                        <?php if($errors->has('doctor_hospital')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('doctor_hospital')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-md-6">
                                        <label for="doctor_mobile">Mobile <span class="req">*</span> </label>
                                        <input type="number" min="0" class="form-control" id="doctor_mobile" name="doctor_mobile" value="<?php echo e(old('doctor_mobile', empty($errors->doctor_mobile) ? '' : $errors->doctor_mobile)); ?>" placeholder="01478965421">
                                        <?php if($errors->has('doctor_mobile')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('doctor_mobile')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="doctor_experince">Experince Year<span class="req">*</span> </label>
                                        <input type="number" min="11" class="form-control" id="doctor_experince" name="doctor_experince" value="<?php echo e(old('doctor_experince', empty($errors->doctor_experince) ? '' : $errors->doctor_experince)); ?>" placeholder="Example: 5">
                                        <?php if($errors->has('doctor_experince')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('doctor_experince')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    
                                    <div class="col-md-6">
                                        <label for="doctor_image">Image <span class="req">*</span> </label>
                                        <input type="file" class="form-control" id="doctor_image" name="doctor_image" value="<?php echo e(old('doctor_image', empty($errors->doctor_image) ? '' : $errors->doctor_image)); ?>">
                                        <?php if($errors->has('doctor_image')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('doctor_image')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-md-12">
                                        <label for="doctor_details">Write few words about you (Optional)</label>
                                        <textarea name="doctor_details" class="form-control" id="doctor_details" cols="30" rows="4" placeholder="Write few words about you..."></textarea>
                                        <?php if($errors->has('doctor_details')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('doctor_details')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                
                                
                                <button type="submit" class="btn btn-success mb-3">Register</button>
                            </div>
                        </form>

                        
                      </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
<?php /**PATH /opt/lampp/htdocs/our-doctors-laravel/resources/views/layouts/partials/header.blade.php ENDPATH**/ ?>