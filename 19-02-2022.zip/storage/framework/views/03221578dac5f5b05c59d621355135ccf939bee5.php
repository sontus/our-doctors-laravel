<?php $__env->startSection('title','Hospital List'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
 <!-- hospitals start -->
 <div class="container hospitals mt-2">
    <h3 class="text-center">Nearest Hospitals</h3>
    <div class="row">
        <?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-12 col-md-3 col-lg-3 hospital-box">
                <img src="<?php echo e(asset('storage/hospitals/'.$hospital->logo)); ?>" alt="hospital">
                <h5><?php echo e($hospital->name); ?></h5>
                <p><?php echo e($hospital->address); ?></p>
                <a href="<?php echo e($hospital->map_location); ?>" class="btn btn-outline-success" target="_blank"><span class="fas fa-map-marker-alt ml-2" ></span> Show on Maps</a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<!-- hospitals end-->




<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/our-doctors-laravel/resources/views/hospital-list.blade.php ENDPATH**/ ?>